# ChesHamm

A handmade font. Heavy, chunky, a little bit funny. Every single character — Cyrillic, Latin, digits, punctuation — drawn by hand.

I spent 1.5 hours making it
Free for anything. Personal, commercial, logos, printing, web, apps — I don't care. Just don't sell it as yours.

No company owns this font. Only me. Hanarboj / malaka butilka

Made out of spite. Free forever.